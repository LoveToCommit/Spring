SPRING WEB SERVICES

This directory contains a client for the Airline Web Service that uses JMS: Java Message Service. The client can be run
from the provided ant file, by calling "ant run".

JMS Client Sample table of contents
---------------------------------------------------
* src - The source files for the client
* build.xml -  Ant build file with a 'build' and a 'run' target

