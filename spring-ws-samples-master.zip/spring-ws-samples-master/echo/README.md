# Echo Sample

This sample shows a bare-bones echoing service. Incoming messages are handled
via DOM, and a simple 'business logic' service is used to obtain the result.

## Build and deploy

See the main [README](../README.md) for build instructions.

## License

[Spring Web Services] is released under version 2.0 of the [Apache License].

[Spring Web Services]: http://projects.spring.io/spring-ws
[Apache License]: http://www.apache.org/licenses/LICENSE-2.0