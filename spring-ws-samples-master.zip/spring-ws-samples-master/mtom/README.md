# MTOM Sample

This sample shows how to use marshal and unmarshal MTOM attachments using JAXB2.

## Build and deploy

See the main [README](../README.md) for build instructions.

## License

[Spring Web Services] is released under version 2.0 of the [Apache License].

[Spring Web Services]: http://projects.spring.io/spring-ws
[Apache License]: http://www.apache.org/licenses/LICENSE-2.0