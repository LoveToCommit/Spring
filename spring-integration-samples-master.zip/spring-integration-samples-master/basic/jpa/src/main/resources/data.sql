insert into PEOPLE(id, name, CREATED_DATE_TIME) values ('1001', 'Cartman', NOW());

INSERT INTO SEQUENCE(SEQ_NAME, SEQ_COUNT) values ('SEQ_GEN', 0);
