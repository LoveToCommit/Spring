/*
 * Copyright 2002-2015 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.integration.samples.loanbroker.loanshark.biz;

import org.springframework.dao.DataAccessException;
import org.springframework.integration.samples.loanbroker.loanshark.domain.LoanShark;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * @author Gary Russell
 *
 */
@Service
public class Accumulator {

	@Transactional
	public void accumulate(SharkQuote quote) {
		LoanShark shark = null;
		try {
			shark = (LoanShark) LoanShark.findLoanSharksByName(
					quote.getSharkName()).getSingleResult();
		} catch (DataAccessException dae) {}
		if (shark == null) {
			shark = new LoanShark();
			shark.setName(quote.getSharkName());
			shark.setCounter(Long.valueOf(0));
			shark.setAverageRate(0.0d);
			shark.persist();
		}
		Double current = shark.getCounter() * shark.getAverageRate();
		shark.setCounter(shark.getCounter().longValue() + 1);
		shark.setAverageRate((current + quote.getSharkRate()) / shark.getCounter());
	}

}
