/*
 * Copyright 2005-2010 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.ws.soap.stroap;

import java.util.NoSuchElementException;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

import org.springframework.util.Assert;
import org.springframework.xml.stream.AbstractXMLEventReader;

/**
 * @author Arjen Poutsma
 */
class NonCachingStroapPayload extends StroapPayload {

	private final XMLEventReader eventReader;

	private int elementDepth = 0;

	NonCachingStroapPayload(XMLEventReader eventReader) throws XMLStreamException {
		Assert.notNull(eventReader, "'eventReader' must not be null");
		this.eventReader = eventReader;
	}

	@Override
	public QName getName() {
		try {
			XMLEvent event = eventReader.peek();
			if (event != null && event.isStartElement()) {
				return event.asStartElement().getName();
			}

		}
		catch (XMLStreamException ex) {
			// ignore
		}
		return null;
	}

	@Override
	public XMLEventReader getEventReader() {
		return new NonCachingXMLEventReader();
	}

	private class NonCachingXMLEventReader extends AbstractXMLEventReader {

		public boolean hasNext() {
			return elementDepth >= 0 && eventReader.hasNext();
		}

		public XMLEvent nextEvent() throws XMLStreamException {
			if (elementDepth < 0) {
				throw new NoSuchElementException();
			}
			XMLEvent event = eventReader.nextEvent();
			if (event.isStartElement()) {
				elementDepth++;
			}
			else if (event.isEndElement()) {
				elementDepth--;
			}
			return event;
		}

		public XMLEvent peek() throws XMLStreamException {
			if (elementDepth < 0) {
				return null;
			}
			else {
				return eventReader.peek();
			}
		}
	}
}
