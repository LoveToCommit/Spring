/**
 * Provides classes supporting inbound endpoints.
 */
package org.springframework.integration.amqp.inbound;
