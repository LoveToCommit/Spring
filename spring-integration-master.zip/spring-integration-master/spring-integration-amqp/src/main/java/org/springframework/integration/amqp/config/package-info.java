/**
 * Provides classes for configuration - parsers, namespace handlers, factory beans.
 */
package org.springframework.integration.amqp.config;
