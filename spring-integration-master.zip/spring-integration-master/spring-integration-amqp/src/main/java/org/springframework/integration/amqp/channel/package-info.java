/**
 * Provides classes related to AMQP-backed channels.
 */
package org.springframework.integration.amqp.channel;
