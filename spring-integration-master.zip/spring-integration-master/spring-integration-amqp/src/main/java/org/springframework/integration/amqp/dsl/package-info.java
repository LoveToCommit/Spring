/**
 * Provides AMQP Component support for the Java DSL.
 */
package org.springframework.integration.amqp.dsl;
