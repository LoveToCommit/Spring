/**
 * Base package for AMQP support.
 */
package org.springframework.integration.amqp;
