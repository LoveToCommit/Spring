/**
 * Contains MessageChannel Builders DSL.
 */
package org.springframework.integration.dsl.channel;
