/**
 * Provides various support classes used across Spring Integration Java DSL Components.
 */
package org.springframework.integration.dsl.support;
