/**
 * Provides classes relating to application context configuration.
 */
package org.springframework.integration.context;
