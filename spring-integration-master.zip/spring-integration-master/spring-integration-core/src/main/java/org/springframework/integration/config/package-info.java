/**
 * Base package for configuration.
 */
package org.springframework.integration.config;
