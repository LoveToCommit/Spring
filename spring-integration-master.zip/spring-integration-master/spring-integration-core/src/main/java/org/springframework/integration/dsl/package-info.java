/**
 * Root package of the Spring Integration Java DSL.
 */
package org.springframework.integration.dsl;
