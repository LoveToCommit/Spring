/**
 * Provides classes supporting the capture of message history.
 */
package org.springframework.integration.history;
