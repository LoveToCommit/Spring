/**
 * Provides classes supporting messaging gateways.
 */
package org.springframework.integration.gateway;
