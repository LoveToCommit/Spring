/**
 * Provides classes supporting SpEL expressions.
 */
package org.springframework.integration.expression;
