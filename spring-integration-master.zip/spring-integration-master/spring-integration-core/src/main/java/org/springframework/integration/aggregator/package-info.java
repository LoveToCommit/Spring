/**
 * Provides classes related to message aggregation.
 */
package org.springframework.integration.aggregator;
