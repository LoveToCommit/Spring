/**
 * Provides classes related to endpoint management.
 */
package org.springframework.integration.endpoint.management;
