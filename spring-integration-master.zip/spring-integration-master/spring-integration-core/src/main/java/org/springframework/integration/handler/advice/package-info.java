/**
 * Provides classes that are used to advise
 * {@link org.springframework.messaging.MessageHandler}s with
 * cross-cutting concerns.
 */
package org.springframework.integration.handler.advice;
