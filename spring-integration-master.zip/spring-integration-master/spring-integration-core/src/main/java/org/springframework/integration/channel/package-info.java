/**
 * Provides classes representing various channel types.
 */
package org.springframework.integration.channel;
