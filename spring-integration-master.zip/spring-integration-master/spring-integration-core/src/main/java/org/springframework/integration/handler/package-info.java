/**
 * Provides classes implementing various types of message handler.
 */
package org.springframework.integration.handler;
