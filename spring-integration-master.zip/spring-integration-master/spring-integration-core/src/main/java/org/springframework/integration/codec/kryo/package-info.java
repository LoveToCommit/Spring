/**
 * The <a href="https://code.google.com/p/kryo/">Kryo</a> specific {@code Codec} classes.
 */
package org.springframework.integration.codec.kryo;
