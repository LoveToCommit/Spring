/**
 * Provides classes supporting the filter pattern.
 */
package org.springframework.integration.filter;
