/**
 * Provides classes supporting JSON in Spring Integration.
 */
package org.springframework.integration.json;
