/**
 * Provides core classes related to Endpoints.
 */
package org.springframework.integration.endpoint;
